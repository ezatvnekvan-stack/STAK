API 35 emulator screenshots. Title and episode screenshots use an isolated test fixture; they do not establish live provider success.
